<script src='<?=base_url()?>js/generalFiles/jquery.min.js'></script>
<script src='<?=base_url()?>js/generalFiles/jquery.easing.min.js'></script>
<script src="<?=base_url()?>js/generalFiles/sweetalert.min.js"></script>
<script src="<?=base_url()?>js/generalFiles/jspdf.min.js"></script>
<script src="<?=base_url()?>js/Forms/operations.js"></script>
<script src="<?=base_url()?>js/Forms/index.js"></script>
</body>
</html>