<script src='<?=base_url()?>js/generalFiles/jquery.min.js'></script>
<script src='<?=base_url()?>js/generalFiles/jquery.easing.min.js'></script>
<script src="<?=base_url()?>js/Forms/index.js"></script>
</body>
</html>