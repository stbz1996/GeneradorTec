<!DOCTYPE html>
<html lang="en" >

<head>
	<meta charset="UTF-8">
  	<title><?= $title ?></title>
  	<link rel="stylesheet" href="<?=base_url()?>css/Forms/errorPage_style.css">
</head>


<body>

	<div class="imgTEC">
	    <img src="https://www.tec.ac.cr/sites/default/files/media/branding/logo-tec.png">
	</div>

	<div>
		<p>Formulario <?= $msg ?>, ante cualquier consulta contacte a Secretaría</p>
		<p>Gracias por su compresión</p>
	</div>

</body>