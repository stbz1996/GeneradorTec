<div>
    <h1></h1>
    <p></p>
</div>

<!-- Todo el contenido -->
<div>
</div>

<!-- Los botones -->
<div class="modal-footer">

</div>