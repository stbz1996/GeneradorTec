<!-- Los tituloso -->
<div>
    <h1>Titulo grande</h1>
    <p>Explicacion de lo que hay en la página</p>
</div>

<hr>

<!-- Todo el contenido -->
<div>
    Aqui el contenido
</div>

<hr>

<!-- Los botones -->
<div class="modal-footer">
    Aqui los botones
</div>