<!-- Todo el contenido -->
<div class="imgTEC">
	<img src="https://www.tec.ac.cr/sites/default/files/media/branding/logo-tec.png">
</div>