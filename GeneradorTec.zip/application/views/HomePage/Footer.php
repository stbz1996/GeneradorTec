

            </div>
        </div>
    </main>
    </div>
    <!-- page-wrapper -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?=base_url()?>js/HomePage/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="<?php echo base_url('css/bootstrap/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('css/datatables/js/jquery.dataTables.min.js')?>"></script>
    <script src="<?php echo base_url('css/datatables/js/dataTables.bootstrap.js')?>"></script>
    <script src="<?php echo base_url('js/modal.js')?>"></script>
    <script src="<?=base_url()?>js/HomePage/custom.js"></script>
    <script src="<?=base_url()?>js/HomePage/operations.js"></script>
</body>
</html>