function showEmailSent(){
	
	var date   = document.getElementById("dateForLinks");
	var period = document.getElementById("periodForLinks");

	$.ajax({
		url: "../GenerateLinks_controller/generateLinks",
		type: "POST",
		data:{
			dateForLinks: date.value,
			periodForLinks: period.options[period.selectedIndex].value
		},
		beforeSend: function(){
            
        },
		success: function(data){
			var msj = "";
			var professors = JSON.parse(data);
			if (professors.length == 0) {
				swal('Ya han sido enviados los correos para este periodo', '', 'info');
			}
			else{
				for (var i = 0; i < professors.length; i++) {
					msj += professors[i] + "\r\n";
				}
				swal('El correo se envió a los siguientes profesores', msj, 'success');
			}
		},
		error: function ()
        {
            alert('falló');
        }
	});
}